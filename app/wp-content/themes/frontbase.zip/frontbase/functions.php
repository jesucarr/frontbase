<?php 

namespace FrontBase;

require_once('lib/enqueues.php');
require_once('lib/title.php');
require_once('lib/searchform.php');
require_once('lib/comments.php');
require_once('lib/menus.php');
require_once('lib/widget-areas.php');



?>